// export default 'http://localhost:3000'
export default 'http://watermyplant-backend-env.x589jebncj.us-east-1.elasticbeanstalk.com'